# Summarize_covid
Node JS API for fetching data on Covid - 19 worldwide.

# How to run the Project

`git clone <https_link_for_the_repo>`

`npm install`

"Make sure you install serverless offline globally in your system(if any serverless error is observed)"
After successfull installation of serverless offline is done, now its time to run the project.

`sls offline` or

`serverless offline`

the base api url for the offline api would be at your localhost:3000 

API documentation:
